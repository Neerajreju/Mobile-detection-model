# mobile phone detection > 2022-01-19 3:28pm
https://universe.roboflow.com/collab/mobile-phone-detection

Provided by a Roboflow user
License: Public Domain

